package Common.Constant;

import org.openqa.selenium.WebDriver;

import java.time.Duration;

public class Constant {
    public static WebDriver WEBDRIVER;
    public static final String AUTOMATIONEXERCISE_URL = "https://www.automationexercise.com/";
    public static final String NAME = "Phuc An";
    public static final String PASSWORD = "12345678";
    public static final String FIRSTNAME = "Kata";
    public static final String LASTNAME = "Kaze";
    public static final String ADDRESS = "123 Hoang Van Thu";
    public static final String COUNTRY = "CCC";
    public static final String STATE = "SSS";
    public static final String CITY = "CCC";
    public static final String ZIPCODE = "12345";
    public static final String MOBILE_PHONE = "0123456789";
    public static final Duration TIMEOUT = Duration.ofSeconds(20);
    public static final String FORMATDATETIME = "M/d/yyyy";
}